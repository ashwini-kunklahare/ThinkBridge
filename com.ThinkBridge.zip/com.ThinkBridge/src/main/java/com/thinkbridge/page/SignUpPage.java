
package com.thinkbridge.page;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.thinkbridge.Base.Base;

public class SignUpPage extends Base {

	public SignUpPage() {
		super();
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@id='language']//span[2]")
	private WebElement Dropdown;
	@FindBy(css = "#name")
	private WebElement FullName;
	@FindBy(css = "#orgName")
	private WebElement orgName;
	@FindBy(css = "#singUpEmail")
	private WebElement email;
	@FindBy(xpath = "//span[@class='black-color ng-binding']")
	private WebElement checkBox;
	@FindBy(xpath = "//button[contains(text(),'Get Started')]")
	private WebElement getStartedBtn;
	@FindBy(className = "ng-binding")
	private By confirmationMessage;
	
	public void dropdown() {
		Select select = new Select(Dropdown); 
	       java.util.List<WebElement> options = select.getOptions(); 
	        for(WebElement item:options) 
	        { 
	        
	             System.out.println("Dropdown values are "+ item.getText());          
	           }

		
		//String options = driver.findElement(By.xpath("//div[@id='language']//span")).getText();
		//System.out.println(options);

	}

	public void enterFullName() {
		FullName.sendKeys(prop.getProperty("Fullname"));

	}

	public void enterOrgName() {
		orgName.sendKeys(prop.getProperty("OrgName"));
	}

	public void enterEmail() {
		email.sendKeys(prop.getProperty("Email"));
	}
	public void ClickOncheckBox() {
		checkBox.click();
	}
	public void ClickOnGetStartedBtn() {
        getStartedBtn.click();
	}
	public String validateMessage() {
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.textToBe(confirmationMessage, "A welcome email has been sent. Please check your email."));
		return ((WebElement) confirmationMessage).getText();

	}

	
}
