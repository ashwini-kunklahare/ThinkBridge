package com.thinkbridge.test;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.thinkbridge.page.SignUpPage;

public class SignUpPageTest extends SignUpPage {
	

	SignUpPage SignUp;

	@BeforeClass
	public void initMethod() {
		openBrowserAnConfigure();
		launchURL();
		SignUp = new SignUpPage();
	}

	@Test(description = "To verify user is able to SignUp successfully")
	public void userSignUp() throws InterruptedException {
		extentLog = extent.createTest("verify_UserSignup");
		SignUp.dropdown();
		SignUp.enterFullName();
		SignUp.enterOrgName();
		SignUp.enterEmail();
		Thread.sleep(3000);
		SignUp.ClickOncheckBox();
		SignUp.ClickOnGetStartedBtn();
		Thread.sleep(5000);
		SignUp.validateMessage();
        Assert.assertEquals(validateMessage(),"A welcome email has been sent. Please check your email.");

	}

	@AfterClass
	public void tearDown() {
		closeBrowserWindow();
	}

}
